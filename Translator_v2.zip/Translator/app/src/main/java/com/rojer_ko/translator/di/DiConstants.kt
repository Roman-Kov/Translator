package com.rojer_ko.translator.di

internal const val NAME_REMOTE = "Remote"
internal const val NAME_LOCAL = "Local"

